
#!/bin/bash

#
# THIS SCRIPT IS GENERATED AND SHOULD NOT BE EDITED DIRECTLY
#

set -e

export HOST_IP

check_env() {
  if [[ -z "$HOST_IP" || -z "$POSTGRES_PASSWORD" || -z "$DOLTHUBAPI_PASSWORD" ]]; then
    echo "Must supply HOST_IP, POSTGRES_PASSWORD, and DOLTHUBAPI_PASSWORD"
    exit 1
  fi
}

create_token_keys() {
  chmod +x ./gentokenenckey
  ./gentokenenckey > iter_token.keys
}

update_images() {
  docker-compose pull
}

start_services() {
  POSTGRES_PASSWORD="$POSTGRES_PASSWORD" \
  DOLTHUBAPI_PASSWORD="$DOLTHUBAPI_PASSWORD" \
  POSTGRES_USER=dolthubadmin \
  docker-compose up -d
}

_main() {
    check_env
    create_token_keys
    update_images
    start_services
}

_main

